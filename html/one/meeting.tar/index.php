<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body bgcolor="#272727">
<ul class="main">
  <li class="date">
  <h3><?php echo date("M d");?></h3>
    <p>Schedule of Events</p>
  </li>
  <li class= "events">
    <ul class="events-detail">
      <li>
        <a href="#">
          <span class="event-time"><?php system('cat meetingTimeOne');?></span>&nbsp;&nbsp;
          <span class="event-name"><?php system('cat meetingBookOne');?></span>&nbsp;&nbsp;
          <br />
          <span class="event-location"><?php system('cat meetingRoomOne');?></span>
        </a>
      </li>
       <li>
        <a href="#">
          <span class="event-time"><?php system('cat meetingTimeTwo');?></span>&nbsp;&nbsp;
          <span class="event-name"><?php system('cat meetingBookTwo');?></span>&nbsp;&nbsp;
          <br />
          <span class="event-location"><?php system('cat meetingRoomTwo');?></span>
        </a>
      </li>
    </ul>  
  </li>
</ul>  
</body>
</html>
